#include <stdio.h>

int main() {
    //Your code here
    printf("Hello, Voltera!");

    return 0;
}